<?php

namespace App\Controller;

use App\Entity\Team;
use App\Repository\TeamRepository;
use Doctrine\ORM\EntityManagerInterface;
use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\HttpFoundation\JsonResponse;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\Routing\Annotation\Route;

#[Route('/Team')]
class TeamController extends AbstractController
{
    #[Route('/', name: 'create_new_team' , methods: ["POST"])]
    public function newTeam(EntityManagerInterface $em, Request $request): JsonResponse
    {
        $parameters = json_decode($request->getContent(), true);

        $Team = new Team();
        $Team->setName($parameters["name"]);
        $Team->setMascot($parameters["mascot"]);

        $em->persist($Team); 
        $em->flush();

        return $this->json("Team saved");
    }

    #[Route('/', name: 'get_all_Team' , methods:["GET"])]
    public function index(TeamRepository $TeamRepository): JsonResponse
    {

        $Teams = $TeamRepository ->findAll();

        return $this->json($Teams);
    }

    #[Route('/{id}', name: 'update_Team' , methods: ["PUT"])]
    public function editTeam(EntityManagerInterface $em, Request $request, int $id): JsonResponse
    {
        $TeamRepository = $em->getRepository(Team::class);
        $Team = $TeamRepository->find($id);

        $parameters = json_decode($request->getContent(), true);

        $Team->setName($parameters["name"]);
        $Team->setMascot($parameters["mascot"]);

        $em->persist($Team); 
        $em->flush();

        return $this->json("Team updated");
    }

    #[Route('/{id}', name: 'delete_Team' , methods: ["DELETE"])]
    public function deleteTeam(EntityManagerInterface $em, int $id): JsonResponse
    {
        $TeamRepository = $em->getRepository(Team::class);
        $Team = $TeamRepository->find($id);

        if(is_null($Team)){
            return $this->json("Team deleted");
        }

        $em->remove($Team); 
        $em->flush();

        return $this->json("Team deleted");
    }

}